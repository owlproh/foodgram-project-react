import base64

import webcolors
from django.core.files.base import ContentFile
from django.shortcuts import get_object_or_404
from recipes.models import (Favorite, Ingredient, Ingredient_to_Recipe, Recipe,
                            Shopping_Cart, Tag)
from rest_framework import serializers
from rest_framework.validators import UniqueTogetherValidator

from .serializers_users import UserSerializer


class Hex2NameColor(serializers.Field):
    def to_representation(self, value):
        return value

    def to_internal_value(self, data):
        try:
            data = webcolors.hex_to_name(data)
        except ValueError:
            raise serializers.ValidationError(
                'Для этого цвета не придумали названия'
            )
        return data


class Base64ImageField(serializers.ImageField):
    def to_internal_value(self, data):
        if isinstance(data, str) and data.startswith('data:image'):
            format, imgstr = data.split(';base64,')
            ext = format.split('/')[-1]
            data = ContentFile(base64.b64decode(imgstr), name='temp.' + ext)
        return super().to_internal_value(data)


class TagSerializer(serializers.Serializer):
    """Сериализатор модели Tag"""
    color = Hex2NameColor()

    class Meta:
        model = Tag
        fields = (
            'id',
            'name',
            'color',
            'slug',
        )


class IngredientSerializer(serializers.Serializer):
    """Сериализатор модели Ingredient"""
    class Meta:
        model = Ingredient
        fields = (
            'id',
            'name',
            'measurement_unit',
        )


class FavoriteSerializer(serializers.Serializer):
    """Сериализатор модели Favorite"""
    class Meta:
        model = Favorite
        fields = (
            'recipe',
            'user',
        )
        validators = [
            UniqueTogetherValidator(
                queryset=Favorite.objects.all(),
                fields=('user', 'recipe'),
                message='Этот рецепт уже добавлен в Избранное'
            )
        ]


class ItRSerializer(serializers.Serializer):
    """Сериализатор модели Ingredient_to_Recipe"""
    id_ingredient = serializers.PrimaryKeyRelatedField(
        queryset=Ingredient.objects.all()
    )

    class Meta:
        model = Ingredient_to_Recipe
        fields = (
            'id_ingredient',
            'cnt'
        )


class CartSerializer(serializers.Serializer):
    """Сериализатор модели Shopping_Cart"""
    class Meta:
        model = Shopping_Cart
        fields = (
            'recipe',
            'user',
        )
        validators = [
            UniqueTogetherValidator(
                queryset=Shopping_Cart.objects.all(),
                fields=("recipe", "user"),
                message='Этот рецепт уже в корзине'
            )
        ]


class RecipeGETSerializer(serializers.Serializer):
    """Сериализатор модели Recipe для GET-запросов"""
    is_favorited = serializers.SerializerMethodField(read_only=True)
    is_in_cart = serializers.SerializerMethodField(read_only=True)
    author = UserSerializer(read_only=True)
    ingredients = serializers.SerializerMethodField()
    image = Base64ImageField(required=True, allow_null=True)
    tags = TagSerializer(many=True, read_only=True)

    @staticmethod
    def get_ingredients(obj):
        ingredients = Ingredient_to_Recipe.objects.filter(recipe=obj)
        return IngredientSerializer(ingredients, many=True).data

    def get_is_favorited(self, obj):
        user = self.context.get('request').user
        if user.is_anonymous:
            return False
        return user.favorite.filter(recipe=obj).exists()

    def get_is_in_cart(self, obj):
        user = self.context.get('request').user
        if user.is_anonymous:
            return False
        return user.shopping_cart.filter(recipe=obj).exists()

    class Meta:
        model = Recipe
        fields = (
            'id',
            'ingredients',
            'tags',
            'image',
            'name',
            'text',
            'cooking_time',
            'author',
            'pub_date'
        )


class RecipeSerializer(serializers.Serializer):
    """Сериализатор модели Recipe"""
    ingredients = ItRSerializer(many=True)
    image = Base64ImageField(required=True, allow_null=True)
    tags = TagSerializer(many=True, read_only=True)
    author = UserSerializer(read_only=True)

    class Meta:
        model = Recipe
        fields = (
            'id',
            'ingredients',
            'tags',
            'image',
            'name',
            'text',
            'cooking_time',
            'author',
            'pub_date'
        )

    def validate(self, data):
        ingredients = data['ingredients']
        unique_ings = []
        for ingredient in ingredients:
            name = ingredient['id_ingredient']
            if int(ingredient['cnt']) <= 0:
                raise serializers.ValidationError(
                    f'Не корректное количество для {name}'
                )
            if name not in unique_ings:
                unique_ings.append(name)
            else:
                raise serializers.ValidationError('Ингредиенты повторяются!')
        return data

    def create(self, validated_data):
        ingredients_data = validated_data.pop('ingredients')
        tags_data = validated_data.pop('tags')
        recipe = Recipe.objects.create(**validated_data)
        tags = [
            get_object_or_404(Tag, **tag)
            for tag in tags_data
        ]
        ingredients = [
            get_object_or_404(Ingredient, **ingredient)
            for ingredient in ingredients_data
        ]
        recipe.tags = tags
        recipe.ingredients = ingredients
        recipe.save()
        return recipe

    @staticmethod
    def create_ingredients(self, ingredients, recipe):
        Ingredient_to_Recipe.objects.bulk_create(
            [Ingredient_to_Recipe(
                recipe=recipe,
                ingredient_id=ingredient.get('id'),
                cnt=ingredient.get('cnt')
            ) for ingredient in ingredients
            ]
        )

    def update(self, instance, validated_data):
        ingredients_data = validated_data.pop('ingredients')
        tags_data = validated_data.pop('tags')
        if tags_data:
            instance.tags.set(tags_data)
        if ingredients_data:
            instance.ingredients.clear()
            self.create_ingredients(ingredients_data, instance)
        for key, value in validated_data.items():
            setattr(instance, key, value)
        instance.save()
        return instance

    def to_representation(self, instance):
        return RecipeGETSerializer(instance).data
