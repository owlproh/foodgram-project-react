from django.db.models import Exists, OuterRef, Sum
from django.http import HttpResponse
from django.shortcuts import get_object_or_404
from django_filters.rest_framework import DjangoFilterBackend
from recipes.models import (Favorite, Ingredient, Ingredient_to_Recipe, Recipe,
                            Shopping_Cart, Tag)
from rest_framework import filters, permissions, status, viewsets
from rest_framework.decorators import action
from rest_framework.response import Response

from .filters import IngredientFilter, RecipeFilter
from .permissions import IsOwnerOrReadOnly
from .serializers_recipes import (CartSerializer, FavoriteSerializer,
                                  IngredientSerializer, RecipeGETSerializer,
                                  RecipeSerializer, TagSerializer)


class IngredientViewSet(viewsets.ReadOnlyModelViewSet):
    """Viewset для объектов модели Ingredient"""
    queryset = Ingredient.objects.all()
    serializer_class = IngredientSerializer
    permission_classes = (permissions.IsAuthenticatedOrReadOnly,)
    filter_backends = (DjangoFilterBackend, filters.SearchFilter,)
    filtreset_class = IngredientFilter
    search_fields = ('^name',)


class TagViewSet(viewsets.ModelViewSet):
    """Viewset для объектов модели Tag"""
    queryset = Tag.objects.all()
    serializer_class = TagSerializer
    permission_classes = (permissions.IsAuthenticatedOrReadOnly,)


class RecipeViewSet(viewsets.ModelViewSet):
    """Viewset для объектов модели Recipe"""
    queryset = Recipe.objects.all()
    serializer_class = RecipeSerializer
    permission_classes = (IsOwnerOrReadOnly,)
    filter_backends = (DjangoFilterBackend,)
    filterser_class = RecipeFilter
    ordering = ('-pub_date',)

    def get_queryset(self):
        return (
            super().get_queryset().annotate(
                is_in_shopping_cart=Exists(
                    Shopping_Cart.objects.filter(
                        user=self.request.user.id,
                        cart_id=OuterRef("pk")
                    )
                ),
                is_favorited=Exists(
                    Favorite.objects.filter(
                        user=self.request.user.id,
                        favorite_id=OuterRef("pk")
                    )
                ),
            )
        )

    def get_serializer_class(self):
        """Определяет какой сериализатор нужен
         (в зависимости от метода запроса)"""
        if self.request.method == 'GET':
            return RecipeGETSerializer
        return RecipeSerializer

    def perform_create(self, serializer):
        """"Передает в поле author данные о пользователе"""
        serializer.is_valid(raise_exception=True)
        serializer.save(author=self.request.user)

    def perform_destroy(self, instance):
        """Удаляет объект класса рецепт"""
        if self.request.user != instance.author:
            raise Exception('Только автор может удалять рецепт')
        instance.delete()

    @action(
            methods=['POST', 'DELETE'],
            detail=True,
            url_path='favorite',
            url_name='favorite'
    )
    def favorite(self, request, pk):
        """Для добавления/удаления в/из Избранное"""
        recipe = get_object_or_404(Recipe, pk=pk)
        if request.method == 'POST':
            serializer = FavoriteSerializer(
                data={
                    'user': request.user.id,
                    'recipe': recipe.id
                }
            )
            serializer.is_valid(raise_exception=True)
            serializer.save()
            serializer = RecipeSerializer(recipe)
            return Response(
                serializer.data,
                status=status.HTTP_201_CREATED
            )
        get_object_or_404(
            Favorite,
            user=request.user,
            recipe=recipe
        ).delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

    @action(
            methods=['POST', 'DELETE'],
            detail=True,
            url_path='shopping_cart',
            url_name='shopping_cart'
    )
    def cart(self, request, pk):
        """Для добавления/удаления в/из корзину"""
        recipe = get_object_or_404(Recipe, pk=pk)
        if request.method == 'POST':
            serializer = CartSerializer(
                data={
                    'user': request.user.id,
                    'recipe': recipe.id
                }
            )
            serializer.is_valid(raise_exception=True)
            serializer.save()
            serializer = RecipeSerializer(recipe)
            return Response(
                serializer.data,
                status=status.HTTP_201_CREATED
            )
        get_object_or_404(
            Shopping_Cart,
            user=request.user,
            recipe=recipe
        ).delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

    @action(
        methods=['GET'],
        detail=False,
        permission_classes=(permissions.IsAuthenticated,)
    )
    def download_shopping_cart(self, request):
        ingredients = Ingredient_to_Recipe.objects.select_related(
            'recipe', 'ingredient'
        )
        ingredients = ingredients.filter(
            recipe__shopping_cart_recipe__user=request.user
        )
        ingredients = ingredients.values(
            'ingredient__name', 'ingredient__measurement_unit'
        )
        ingredients = ingredients.annotate(ingredient_total=Sum('amount'))
        ingredients = ingredients.order_by('ingredient__name')
        shopping_list = 'Список покупок: \n'
        for ingredient in ingredients:
            shopping_list += (
                f'{ingredient["ingredient__name"]} - '
                f'{ingredient["ingredient_total"]} '
                f'({ingredient["ingredient__measurement_unit"]}), \n'
            )
            response = HttpResponse(
                shopping_list, content_type='text/plain; charset=utf8'
            )
            response[
                'Content-Disposition'
            ] = 'attachment; filename="shopping_list.txt"'
        return response
